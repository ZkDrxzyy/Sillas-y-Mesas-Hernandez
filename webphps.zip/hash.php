<?php
echo password_hash("12345", PASSWORD_DEFAULT);
?>
