<?php
require_once "conexion.php";

if ($conn) {
    echo "<h2 style='color:green;'>Conexión exitosa</h2>";
}
?>
