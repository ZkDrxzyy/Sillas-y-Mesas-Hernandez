<?php require_once "conexion.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Nuevo Artículo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <h2>Registrar nuevo artículo</h2>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Nombre:</label>
      <input type="text" name="nombre" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Estado:</label>
      <select name="estado" class="form-select">
        <option value="Disponible">Disponible</option>
        <option value="En uso">En uso</option>
        <option value="Dañado">Dañado</option>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Cantidad total:</label>
      <input type="number" name="cantidadTotal" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Costo de renta ($):</label>
      <input type="number" step="0.01" name="costoRenta" class="form-control" required>
    </div>
    <button type="submit" name="guardar" class="btn btn-success">Guardar</button>
    <a href="index.php" class="btn btn-secondary">Volver</a>
  </form>
</div>

<?php
if (isset($_POST['guardar'])) {
    $sql = "INSERT INTO Articulo (nombre, estado, cantidadTotal, costoRenta)
            VALUES (:nombre, :estado, :cantidadTotal, :costoRenta)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':nombre' => $_POST['nombre'],
        ':estado' => $_POST['estado'],
        ':cantidadTotal' => $_POST['cantidadTotal'],
        ':costoRenta' => $_POST['costoRenta']
    ]);
    header("Location: index.php");
}
?>
</body>
</html>
