<?php require_once "conexion.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Inventario - Sillas y Mesas Hernández</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php">Sillas y Mesas Hernández</a>
    <a class="btn btn-success" href="nuevo_articulo.php">+ Nuevo Artículo</a>
  </div>
</nav>

<div class="container mt-4">
  <h2 class="mb-3 text-center">Inventario de Artículos</h2>
  <?php
  try {
      $stmt = $conn->query("SELECT * FROM Articulo ORDER BY idArticulo ASC");
      $articulos = $stmt->fetchAll(PDO::FETCH_ASSOC);

      if ($articulos) {
          echo "<table class='table table-bordered table-striped'>";
          echo "<thead class='table-dark'><tr>
                  <th>ID</th><th>Nombre</th><th>Estado</th>
                  <th>Cantidad</th><th>Costo Renta</th><th>Acciones</th>
                </tr></thead><tbody>";
          foreach ($articulos as $a) {
              echo "<tr>
                      <td>{$a['idArticulo']}</td>
                      <td>{$a['nombre']}</td>
                      <td>{$a['estado']}</td>
                      <td>{$a['cantidadTotal']}</td>
                      <td>\${$a['costoRenta']}</td>
                      <td>
                        <a href='editar_articulo.php?id={$a['idArticulo']}' class='btn btn-sm btn-primary'>Editar</a>
                        <a href='eliminar_articulo.php?id={$a['idArticulo']}' class='btn btn-sm btn-danger' onclick='return confirm(\"¿Seguro que deseas eliminar este artículo?\")'>Eliminar</a>
                      </td>
                    </tr>";
          }
          echo "</tbody></table>";
      } else {
          echo "<div class='alert alert-info'>No hay artículos registrados.</div>";
      }
  } catch (PDOException $e) {
      echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
  }
  ?>
</div>
</body>
</html>
