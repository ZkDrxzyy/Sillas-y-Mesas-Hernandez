<?php
require_once "conexion.php";
if (isset($_GET['id'])) {
    $stmt = $conn->prepare("DELETE FROM Articulo WHERE idArticulo = :id");
    $stmt->execute([':id' => $_GET['id']]);
}
header("Location: index.php");
?>
