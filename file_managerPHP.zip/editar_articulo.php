<?php
require_once "conexion.php";
$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM Articulo WHERE idArticulo = :id");
$stmt->execute([':id' => $id]);
$articulo = $stmt->fetch(PDO::FETCH_ASSOC);

if (isset($_POST['actualizar'])) {
    $sql = "UPDATE Articulo SET nombre=:nombre, estado=:estado, cantidadTotal=:cantidadTotal, costoRenta=:costoRenta WHERE idArticulo=:id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':nombre' => $_POST['nombre'],
        ':estado' => $_POST['estado'],
        ':cantidadTotal' => $_POST['cantidadTotal'],
        ':costoRenta' => $_POST['costoRenta'],
        ':id' => $id
    ]);
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Artículo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <h2>Editar artículo</h2>
  <form method="POST">
    <div class="mb-3">
      <label>Nombre:</label>
      <input type="text" name="nombre" class="form-control" value="<?= $articulo['nombre'] ?>" required>
    </div>
    <div class="mb-3">
      <label>Estado:</label>
      <select name="estado" class="form-select">
        <option <?= $articulo['estado']=='Disponible'?'selected':'' ?>>Disponible</option>
        <option <?= $articulo['estado']=='En uso'?'selected':'' ?>>En uso</option>
        <option <?= $articulo['estado']=='Dañado'?'selected':'' ?>>Dañado</option>
      </select>
    </div>
    <div class="mb-3">
      <label>Cantidad total:</label>
      <input type="number" name="cantidadTotal" class="form-control" value="<?= $articulo['cantidadTotal'] ?>" required>
    </div>
    <div class="mb-3">
      <label>Costo renta ($):</label>
      <input type="number" step="0.01" name="costoRenta" class="form-control" value="<?= $articulo['costoRenta'] ?>" required>
    </div>
    <button type="submit" name="actualizar" class="btn btn-primary">Actualizar</button>
    <a href="index.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>
</body>
</html>
