<?php
$host = "sql.freedb.tech";        
$dbname = "freedb_SillasyMesas";         
$username = "freedb_rootAdmin";    
$password = "Q!ZKCgwruBvG?4H";      

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "<div style='color:red;'>Error de conexión: " . $e->getMessage() . "</div>";
}
?>
